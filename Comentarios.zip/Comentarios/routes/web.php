<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\EmpresaController;
use App\Http\Controllers\AdminController;
use App\Http\Controllers\ExportController;
use App\Http\Controllers\LoginController;
use App\Http\Controllers\ClienteController;
use App\Http\Controllers\ComentarioController;
#use App\Http\Controllers\ImportExcelController;

Route::get('/', function () {
    return view('welcome');
});

Route::get('/', [EmpresaController::class, 'showValidationForm'])->name('validacion.form');
Route::post('/validacion', [EmpresaController::class, 'validateCode'])->name('validacion.validate');
// Ruta para mostrar la pantalla de confirmación del restaurante
Route::get('/confirmacion', [EmpresaController::class, 'showConfirmation'])->name('empresa.confirmacion');

// Ruta para mostrar el formulario de encuesta/comentario
Route::get('/comentario', [EmpresaController::class, 'showSurveyForm'])->name('comentarios.form');

// Ruta para registrar la respuesta (comentario) del cliente
Route::post('/registrar', [EmpresaController::class, 'submitSurvey'])->name('comentario.submit');
//Route::get('/comentario', [EmpresaController::class, 'showSurveyForm'])->name('comentarios.form');
//Route::post('/registrar', [EmpresaController::class, 'submitSurvey'])->name('comentario.submit');
Route::get('/agradecimiento', function () {
    return view('empresa.agradecimiento');
})->name('agradecimiento');



Route::middleware(['web'])->group(function () {
    
        Route::get('/admin/dashboard', [AdminController::class, 'dashboard']) ->name('admin.dashboard');
        Route::get('/admin/comentario/exportar', [EmpresaController::class, 'exportarComentarios'])->name('comentarios.exportar');
        Route::get('/admin/comentarios/{id}', [AdminController::class, 'vercomentario'])->name('comentarios.ver');
            // Rutas para el CRUD de clientes
        Route::get('clientes', [ClienteController::class, 'index'])->name('clientes.index'); // Listado
        Route::get('clientes/create', [ClienteController::class, 'create'])->name('clientes.create'); // Crear cliente
        Route::post('clientes', [ClienteController::class, 'store'])->name('clientes.store'); // Guardar nuevo cliente
        Route::get('clientes/{id}/edit', [ClienteController::class, 'edit'])->name('clientes.edit'); // Editar cliente
        Route::put('clientes/{id}', [ClienteController::class, 'update'])->name('clientes.update'); // Actualizar cliente
        Route::delete('clientes/{id}', [ClienteController::class, 'destroy'])->name('clientes.destroy'); // Eliminar cliente
        Route::get('/exportar-sql', [ExportController::class, 'export'])->name('exportar.sql');
        Route::post('comentarios', [ComentarioController::class, 'store'])->name('comentarios.store');
        Route::get('/login', [LoginController::class, 'showLoginForm'])->name('login');
        Route::post('/login', [LoginController::class, 'authenticate'])->name('admin.authenticate');
        Route::post('/logout', [AdminController::class, 'logout'])->name('admin.logout');
        Route::get('/exportar-sql', [ExportController::class, 'export'])->name('exportar.sql');

        Route::get('/clientes/import', [ClienteController::class, 'showImportForm'])->name('clientes.import');
        Route::post('/clientes/import', [ClienteController::class, 'import'])->name('clientes.import.store');

        Route::post('/enviar-wsp/{id}', [AdminController::class, 'enviarMensajeWsp'])->name('enviar.wsp');
    });
