<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registrar Comentario - Sistema de Comentarios Mr. Soft</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
    <style>
        body {
            background: linear-gradient(90deg, #f8f9fa, #e9ecef);
            font-family: 'Helvetica Neue', Helvetica, Arial, sans-serif;
        }
        .container {
            max-width: 800px;
        }
        h2 {
            text-align: center;
            margin-bottom: 30px;
            text-decoration: underline;
            text-shadow: 2px 2px 4px rgba(0, 0, 0, 0.3);
        }
        .card {
            border: none;
            border-radius: 10px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            margin-bottom: 30px;
        }
        .card-header {
            /*background: linear-gradient(90deg, #fe6055, #ff7b72);*/
            background: linear-gradient(90deg, #007bff, #00c6ff);
            color: #fff;
            font-weight: bold;
            font-size: 1.25rem;
            border-bottom: none;
            padding: 1rem 1.5rem;
        }
        .card-body {
            padding: 1.5rem;
            background-color: #fff;
        }
        .btn-primary {
            /*background: linear-gradient(90deg, #fe6055, #ff7b72);*/
            background: linear-gradient(90deg, #007bff, #00c6ff);
            border: none;
        }
        .stars {
            display: flex;
            justify-content: center;
            gap: 5px;
        }
        .stars input {
            display: none;
        }
        .stars label {
            font-size: 30px;
            color: #ccc;
            cursor: pointer;
            transition: color 0.2s;
        }
        .stars input:checked ~ label {
            color: #ffcc00;
        }
        .stars input:hover ~ label {
            color: #ffcc00;
        }
        .stars label:hover,
        .stars label:hover ~ label {
            color: #ffcc00;
        }
    </style>
</head>
<body>
  
    <!-- Formulario de Registro de Comentario -->
    <div class="container mt-5">
        <h2>Ingrese un Comentario sobre el Servicio ofrecido por Mr.Soft</h2>
        <div class="card">
            <div class="card-header">¡Queremos saber tu opinión!</div>
            <div class="card-body">
                <form action="<?php echo e(route('comentario.submit')); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <input type="hidden" name="idEmpresa" value="<?php echo e($restaurant->idEmpresa); ?>">
                    <div class="mb-3">
                        <label for="comentario" class="form-label">Tu comentario*</label>
                        <textarea class="form-control" id="comentario" name="comentario" rows="3" required></textarea>
                    </div>
                    <div class="mb-3">
                        <label for="calificacion" class="form-label">Calificación del servicio ofrecido (por estrellas)*</label>
                        <div class="stars">
                            <input type="radio" id="star5" name="calificacion" value="5" required>
                            <label for="star5">&#9733;</label>
                            <input type="radio" id="star4" name="calificacion" value="4">
                            <label for="star4">&#9733;</label>
                            <input type="radio" id="star3" name="calificacion" value="3">
                            <label for="star3">&#9733;</label>
                            <input type="radio" id="star2" name="calificacion" value="2">
                            <label for="star2">&#9733;</label>
                            <input type="radio" id="star1" name="calificacion" value="1">
                            <label for="star1">&#9733;</label>
                        </div>
                    </div>
                    <button type="submit" class="btn btn-primary">Registrar Comentario</button>
                </form>
            </div>
        </div>
    </div>

    <script>
        // Simple script to disable submit button if no stars are selected
        document.querySelector('form').addEventListener('submit', function(event) {
            if (!document.querySelector('input[name="calificacion"]:checked')) {
                alert('Por favor, selecciona una calificación.');
                event.preventDefault();
            }
        });
    </script>
</body>
</html>
<?php /**PATH C:\laragon\www\Comentarios\resources\views/comentarios/index.blade.php ENDPATH**/ ?>