<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
  <title>Gestión de Clientes</title>
  <style>
    .card-header {
      background: linear-gradient(90deg, #fe6055, #ff7b72);
      color: #fff;
    }
  </style>
</head>
<body>
  <!-- Navbar tyle="background-color: #343a40;" -->
  <nav class="navbar navbar-expand-lg navbar-dark" style="background: linear-gradient(90deg, #007bff, #00c6ff);">
    <div class="container-fluid">
      <a class="navbar-brand" href="#">Sistema de Comentarios Mr. Soft</a>
      <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbarNav">
        <ul class="navbar-nav">
          <li class="nav-item">
            <a class="nav-link active" aria-current="page" href="<?php echo e(route('admin.dashboard')); ?>">Gestión de Comentarios</a>
          </li>
          <li class="nav-item">
            <a class="nav-link active" aria-current="page" href="<?php echo e(route('clientes.index')); ?>">Gestión de Clientes</a>
          </li>
        </ul>
      </div>
    </div>
  </nav>

  <!-- Contenido -->
  <div class="container mt-5">
    <h1>Listado de Clientes</h1>
    <a href="<?php echo e(route('clientes.create')); ?>" class="btn btn-success mb-3">Añadir Cliente</a>
    <a href="<?php echo e(route('clientes.import')); ?>" class="btn btn-primary mb-3">Importar Excel</a>

    <table class="table">
      <thead class="table-dark">
        <tr>
          <th scope="col">RUC</th>
          <th scope="col">Razón Social</th>
          <th scope="col">Nombre</th>
          <th scope="col">Teléfono</th>
          <th scope="col">codigo de validacion</th>
          <th scope="col">Acciones</th>
        </tr>
      </thead>
      <tbody>
        <?php $__currentLoopData = $clientes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cliente): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
          <td><?php echo e($cliente->Ruc); ?></td>
          <td><?php echo e($cliente->razon_social); ?></td>
          <td><?php echo e($cliente->nombre); ?></td>
          <td><?php echo e($cliente->telefono); ?></td>
          <td><?php echo e($cliente->codigo_validacion); ?></td>
          <td>
            <a href="<?php echo e(route('clientes.edit', $cliente->idEmpresa)); ?>" class="btn btn-primary">Actualizar</a>
            
            <form method="POST" action="<?php echo e(route('clientes.destroy', $cliente->idEmpresa)); ?>" style="display:inline;" onsubmit="return confirm('¿Estás seguro de que deseas eliminar este cliente?');">
              <?php echo csrf_field(); ?>
              <?php echo method_field('DELETE'); ?>
              <button type="submit" class="btn btn-danger">Eliminar</button>
            </form>
          </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </tbody>
    </table>
    <?php if(session('success')): ?>
    <div class="alert alert-success" role="alert">
      <?php echo e(session('success')); ?>

    </div>
    <?php endif; ?>
  </div>
</body>
</html>
<?php /**PATH C:\laragon\www\Comentarios\resources\views/empresa/index.blade.php ENDPATH**/ ?>