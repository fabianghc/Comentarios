<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>¡Gracias por tu respuesta!</title>
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css"/>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" />
  <style>
    body {
      background: linear-gradient(90deg, #f8f9fa, #e9ecef);
      font-family: 'Helvetica Neue', Helvetica, Arial, sans-serif;
    }
    .container {
      max-width: 600px;
    }
    .card {
      border: none;
      border-radius: 12px;
      overflow: hidden;
      box-shadow: 0 4px 16px rgba(0, 0, 0, 0.15);
    }
    .card-header {
      background: linear-gradient(90deg, #007bff, #00c6ff);
      color: #fff;
      font-size: 1.6rem;
      font-weight: bold;
      text-align: center;
      padding: 1rem;
      text-decoration: underline;
      text-shadow: 2px 2px 4px rgba(0, 0, 0, 0.3);
    }
    .card-body {
      padding: 2rem;
    }
    h2 {
      color: #1a1a1a;
      text-shadow: 1px 1px 3px rgba(0,0,0,0.1);
      font-weight: bold;
    }
    .highlight-box {
      background-color: #f1f9ff;
      border-left: 5px solid #007bff;
      border-radius: 6px;
      padding: 1rem;
      margin-top: 1.5rem;
    }
    .highlight-box i {
      color: #007bff;
      margin-right: 0.5rem;
    }
    .lead {
      font-size: 1.15rem;
      margin-bottom: 0.8rem;
    }
  </style>
</head>
<body>
  <div class="container text-center mt-5">
    <div class="card shadow-lg">
      <div class="card-header">
        ¡Agradecemos tu respuesta!
      </div>
      <div class="card-body">
        <h2 class="mb-4">
          <strong>¡Gracias por ayudarnos a mejorar <br> la plataforma PULSO+!</strong>
        </h2>

        <div class="highlight-box text-start">
          <p class="lead"><i class="fas fa-check-circle"></i><b>Tu comentario y calificación han sido registrados correctamente.</b></p>
          <p class="lead"><i class="fas fa-heart"></i><b>Valoramos tu tiempo y compromiso con la mejora continua.</b></p>
        </div>

        <!--<a href="<?php echo e(route('validacion.form')); ?>" class="btn btn-primary mt-3">Volver al inicio</a>-->
      </div>
    </div>
  </div>
</body>
</html>
<?php /**PATH C:\laragon\www\Comentarios\resources\views/empresa/agradecimiento.blade.php ENDPATH**/ ?>