<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
  <title>Dashboard Administrador</title>
</head>
<body>
<nav class="navbar navbar-expand-lg navbar-dark" style="background: linear-gradient(90deg, #007bff, #00c6ff);">
    <div class="container-fluid">
      <a class="navbar-brand" href="#">Sistema de Comentarios</a>
      <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbarNav">
        <ul class="navbar-nav">
          <li class="nav-item">
            <a class="nav-link active" aria-current="page" href="<?php echo e(route('admin.dashboard')); ?>">Gestión de Comentarios</a>
          </li>
          <li class="nav-item">
            <a class="nav-link active" aria-current="page" href="<?php echo e(route('clientes.index')); ?>">Gestión de Clientes</a>
          </li>
        </ul>
      </div>
    </div>
  </nav>
  <div class="container mt-5">
        <h1>Importar Clientes desde Excel</h1>
        <div class="alert alert-info mb-3 mt-3">
        <strong>Importante:</strong> El archivo Excel debe contener las siguientes columnas <strong>en este orden</strong>:
        <ul>
            <li><code>RUC</code></li>
            <li><code>RAZON SOCIAL</code></li>
            <li><code>NOMBRE</code></li>
            <li><code>TELEFONO</code></li>
            <li><code>CODIGO DE VALIDACION</code></li>
        </ul>
        Asegúrate de que los encabezados estén correctamente escritos en la primera fila.
    </div>
        
        <form action="<?php echo e(route('clientes.import.store')); ?>" method="POST" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <div class="mb-3">
                <label for="excel_file" class="form-label">Seleccionar archivo Excel</label>
                <input type="file" class="form-control" id="excel_file" name="excel_file" required>
            </div>
            <button type="submit" class="btn btn-primary">Importar</button>
        </form>
        
    </div>
    
   
</body>
</html>
<?php /**PATH C:\laragon\www\Comentarios\resources\views/clientes/import.blade.php ENDPATH**/ ?>