<?php
    use Illuminate\Support\Facades\Storage;
?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Ver Comentario del Cliente</title>
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
  <style>
    body {
      background-color: #f4f6f9;
    }
    .card {
      border: none;
      border-radius: 10px;
      overflow: hidden;
      box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
    }
    .card-header {
      font-size: 1.25rem;
      font-weight: bold;
      color: #fff;
      padding: 1rem;
    }
    /* Color para la cabecera de "Datos del Restaurante" */
    .card-header.restaurant {
      background: linear-gradient(90deg, #fe6055, #ff7b72);
    }
    /* Color para la cabecera de "Respuesta de la Encuesta" */
    .card-header.encuesta {
      background: linear-gradient(90deg, #fe6055, #ff7b72);
    }
    .card-body {
      background-color: #fff;
      padding: 1.5rem;
    }
    h1 {
      color: #333;
    }
    .stars {
      display: flex;
      justify-content: flex-start;
    }
    .stars input[type="radio"] {
      display: none;
    }
    .stars label {
      font-size: 24px;
      color: #d3d3d3;
      cursor: pointer;
      transition: color 0.2s ease;
    }
    .stars label:hover, .stars label:active, .stars input[type="radio"]:checked ~ label {
      color: #ffcc00;
    }
  </style>
</head>
<body>
  <div class="container my-5">
    <h1 class="mb-4 text-center">📋 Ver Comentario del Cliente</h1>

    <div class="card mb-4">
      <div class="card-header restaurant">Datos del Restaurante</div>
      <div class="card-body">
        <p><strong>Nombre:</strong> <?php echo e($restaurante->nombre); ?></p>
        <p><strong>RUC:</strong> <?php echo e($restaurante->Ruc); ?></p>
        <p><strong>Razón Social:</strong> <?php echo e($restaurante->razon_social); ?></p>
      </div>
    </div>

    <div class="card">
      <div class="card-header encuesta">Comentario Enviado</div>
      <div class="card-body">
        <p><strong>Comentario:</strong> <?php echo e($comentario->comentario); ?></p>

        <div class="stars">
          <?php for($i = 1; $i <= 5; $i++): ?>
            <label for="star<?php echo e($i); ?>" class="<?php echo e($comentario->calificacion >= $i ? 'checked' : ''); ?>">★</label>
          <?php endfor; ?>
        </div>
      </div>
    </div>
  </div>
</body>
</html>

<?php /**PATH C:\laragon\www\Comentarios\resources\views/admin/verencuesta.blade.php ENDPATH**/ ?>