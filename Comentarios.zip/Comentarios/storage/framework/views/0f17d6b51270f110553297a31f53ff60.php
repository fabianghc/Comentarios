<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Encuesta</title>
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
  <style>
    body {
      background-color: #f8f9fa;
      font-family: 'Helvetica Neue', Helvetica, Arial, sans-serif;
    }
    .modal-content {
      border: none;
      border-radius: 10px;
      overflow: hidden;
      box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
    }
    .modal-header {
      /*background: linear-gradient(90deg, #fe6055, #ff7b72);*/
      background: linear-gradient(90deg, #007bff, #00c6ff);
      color: #fff;
      border-bottom: none;
    }
    .modal-title {
      text-decoration: underline;
      text-shadow: 2px 2px 4px rgba(0, 0, 0, 0.3);
      font-weight: bold;
    }
    .modal-body p {
      font-size: 1.1rem;
      color: #495057;
    }
    .modal-footer {
      background-color: #f1f1f1;
      border-top: none;
    }
    .btn-primary {
      /*background: linear-gradient(90deg, #fe6055, #ff7b72);*/
      background: linear-gradient(90deg, #007bff, #00c6ff);
      border: none;
    }
  </style>
</head>
<body>
    <div class="container mt-5">
        <div class="modal fade show" style="display: block;" tabindex="-1">
            <div class="modal-dialog">
                <div class="modal-content">

                    <div class="modal-header">
                        <h5 class="modal-title">¡Bienvenido al espacio de retroalimentación de PULSO+!</h5>
                    </div>

                    <div class="modal-body">
                        <p><strong>Hola <?php echo e($restaurant->nombre); ?></strong></p>
                        <p>
                            Gracias por ser parte de la comunidad de usuarios de <strong>PULSO+</strong>. 
                            Este espacio está diseñado para que puedas compartir tus comentarios, 
                            sugerencias o calificaciones sobre la plataforma.
                            Tu opinión es clave para seguir mejorando nuestras soluciones.
                        </p>
                    </div>

                    <div class="modal-footer">
                        <form action="<?php echo e(route('comentarios.form')); ?>" method="GET">
                            <?php echo csrf_field(); ?>
                            <input type="hidden" name="restaurante_id" value="<?php echo e($restaurant->idRestaurante); ?>">
                            <button type="submit" class="btn btn-primary">Continuar</button>
                        </form>
                    </div>

                </div>
            </div>
        </div>
    </div>
</body>


</html>
<?php /**PATH C:\laragon\www\Comentarios\resources\views/empresa/confirmacion.blade.php ENDPATH**/ ?>