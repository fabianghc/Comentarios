<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Http\Request;
use App\Models\Restaurantes;
use Maatwebsite\Excel\Facades\Excel;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Foundation\Auth\User as Authenticatable;

class Administrador extends Authenticatable
{
    
    
    protected $table = 'administrador';
    protected $fillable = ['usuario', 'contraseña']; 
    protected $hidden = ['contraseña'];
   
    public function getAuthPassword()
    {
        return $this->attributes['contraseña'];  
    }
    
}