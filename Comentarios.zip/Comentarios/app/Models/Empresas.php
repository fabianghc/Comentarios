<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Http\Request;
use App\Models\Empresas;
use Maatwebsite\Excel\Facades\Excel;
use Illuminate\Database\Eloquent\Factories\HasFactory;

class Empresas extends Model
{
    
    use HasFactory;
    protected $table = 'empresa';
    protected $primaryKey = 'idEmpresa'; 
    protected $fillable = ['Ruc', 'razon_social', 'nombre', 'codigo_validacion', 'estado', 'telefono']; 
    
    
    public $timestamps = true;

    
}