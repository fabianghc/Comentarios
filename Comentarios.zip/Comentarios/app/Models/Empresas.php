<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Http\Request;
use App\Models\Empresas;
use Maatwebsite\Excel\Facades\Excel;
use Illuminate\Database\Eloquent\Factories\HasFactory;

class Empresas extends Model
{
    
    use HasFactory;
    protected $table = 'empresa';
    protected $primaryKey = 'idEmpresa'; // Cambia al nombre correcto de la clave primaria
    protected $fillable = ['Ruc', 'razon_social', 'nombre', 'codigo_validacion', 'estado', 'telefono']; 
    
    // Por defecto, Laravel gestionará automáticamente las columnas created_at y updated_at
    public $timestamps = true;

    
}