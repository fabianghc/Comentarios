<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Http\Request;
use App\Models\Empresas;
use Maatwebsite\Excel\Facades\Excel;
use Illuminate\Database\Eloquent\Factories\HasFactory;

class Comentarios extends Model
{
    
    use HasFactory;
    protected $table = 'comentarios';
    protected $primaryKey = 'idComentario'; // Cambia al nombre correcto de la clave primaria
    protected $fillable = ['comentario', 'calificacion', 'idEmpresa']; 
    public function Empresa()
    {
        return $this->belongsTo(Empresas::class);
    }
    
    
}