<?php
namespace App\Http\Controllers;

use Illuminate\Http\Request;
use PhpOffice\PhpSpreadsheet\Spreadsheet;
use PhpOffice\PhpSpreadsheet\Writer\Xlsx;
use App\Models\Comentarios;
use App\Models\Empresas;
use Symfony\Component\HttpFoundation\StreamedResponse;

class ExportController extends Controller
{
    public function export()
    {
        // Crear un nuevo archivo de Excel
        $spreadsheet = new Spreadsheet();
        $sheet = $spreadsheet->getActiveSheet();

        // Definir encabezados
        $headers = [
            'A1' => 'RUC',
            'B1' => 'Nombre',
            'C1' => 'Razón Social',
            'D1' => 'Comentario',
            'E1' => 'Calificación',
        ];

        // Aplicar encabezados con formato
        foreach ($headers as $cell => $value) {
            $sheet->setCellValue($cell, $value);
        }

        // Aplicar estilo a los encabezados (negrita y centrado)
        $styleArray = [
            'font' => [
                'bold' => true
            ],
            'alignment' => [
                'horizontal' => \PhpOffice\PhpSpreadsheet\Style\Alignment::HORIZONTAL_CENTER
            ]
        ];
        $sheet->getStyle('A1:E1')->applyFromArray($styleArray);

        // Obtener datos desde la base de datos
        $comentarios = Comentarios::join('empresa', 'comentarios.idEmpresa', '=', 'empresa.idEmpresa')
            ->select(
                'empresa.Ruc as RUC',
                'empresa.nombre as Nombre',
                'empresa.razon_social as RazonSocial',
                'comentarios.comentario as Comentario',
                'comentarios.calificacion as Calificacion'
            )
            ->get();

        // Insertar datos en las filas
        $row = 2; // Comenzamos en la segunda fila (la primera tiene los encabezados)
        foreach ($comentarios as $comentario) {
            $sheet->setCellValue('A' . $row, $comentario->RUC);
            $sheet->setCellValue('B' . $row, $comentario->Nombre);
            $sheet->setCellValue('C' . $row, $comentario->RazonSocial);
            $sheet->setCellValue('D' . $row, $comentario->Comentario);
            $sheet->setCellValue('E' . $row, $this->getStars($comentario->Calificacion));  // Convertir calificación en estrellas

            $row++;
        }

        // Ajustar automáticamente el ancho de las columnas
        foreach (range('A', 'E') as $col) {
            $sheet->getColumnDimension($col)->setAutoSize(true);
        }

        // Guardar archivo en memoria y devolver como descarga
        $writer = new Xlsx($spreadsheet);
        $response = new StreamedResponse(function () use ($writer) {
            $writer->save('php://output');
        });

        $response->headers->set('Content-Type', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
        $response->headers->set('Content-Disposition', 'attachment;filename="comentarios.xlsx"');
        $response->headers->set('Cache-Control', 'max-age=0');

        return $response;
    }

    // Método para convertir la calificación numérica en estrellas
    private function getStars($calificacion)
    {
        $stars = str_repeat('★', $calificacion) . str_repeat('☆', 5 - $calificacion);
        return $stars;
    }
}

