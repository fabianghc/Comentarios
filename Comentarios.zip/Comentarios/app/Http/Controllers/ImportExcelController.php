<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use PhpOffice\PhpSpreadsheet\IOFactory;
use App\Models\Empresas;

class ImportExcelController extends Controller
{
    public function showImportForm()
    {
        return view('admin.import'); // Vista donde se subirá el archivo
    }

    public function import(Request $request)
    {
        $request->validate([
            'excel_file' => 'required|mimes:xlsx,xls',
        ]);
        $file = $request->file('excel_file');
        $spreadsheet = IOFactory::load($file->getPathname());
        $sheet = $spreadsheet->getActiveSheet();
        $rows = $sheet->toArray();
        foreach ($rows as $index => $row) {
            if ($index == 0) continue; // Omitir encabezados
            $Ruc = $row[0];
            $razon_social = $row[1] ?? null;
            $nombre = $row[2] ?? null;
            $telefono = $row[3] ?? null; 
            $codigo_validacion = $row[4] ?? null;  
            if (!$Ruc) continue;
            // Validar si el cliente ya existe usando campo RUC
            $exists = Empresas::where('Ruc', $Ruc)->exists();
            
            if (!$exists) {
                Empresas::create([
                    'Ruc' => $Ruc,
                    'razon_social' => $razon_social,
                    'nombre' => $nombre,
                    'telefono' => $telefono,
                    'codigo_validacion' => $codigo_validacion,
                    'estado' => 'N', // Estado por defecto
                ]);
            }
        }
        return redirect()->back()->with('success', 'Datos importados correctamente.');
    }
}
