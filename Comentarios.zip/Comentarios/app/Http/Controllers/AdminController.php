<?php
namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use App\Models\Administrador;
use App\Models\Empresas;
use App\Models\Comentarios;
use Illuminate\Routing\Controllers\HasMiddleware;
use Illuminate\Routing\Controllers\Middleware;
use Illuminate\Support\Facades\Http;

class AdminController extends Controller implements HasMiddleware
{
    
  
    public static function middleware(): array
    {
        return [
            'web',
            new Middleware('log', only: ['index']),
            
        ];
    }
    

public function dashboard()
{
    $this->middleware('web');
    #$restaurantes = Restaurantes::all();
    #return view('admin.dashboard', compact('restaurantes'));
    #dd(auth()->guard('admin')->check(), auth()->guard('admin')->user());
     // Verifica si el usuario está autenticado en el guard 'admin'
     if (!session('logueado', false)) { // ✅ Si no está logueado, lo mandamos al login
        #return redirect()->route('admin.login')->withErrors(['error' => 'Debes iniciar sesión']);
        return view('admin.login');
    }
    $restaurantes = Empresas::all();
    return view('admin.dashboard', compact('restaurantes'));

    // Si no está autenticado, devuelve la vista de login
    #return view('admin.login');
}
public function logout()
{
    Auth::guard('web')->logout();
    return redirect()->route('login');
}

public function vercomentario($id)
{
    $cliente = Empresas::findOrFail($id);
    $comentario = Comentarios::where('idEmpresa', $id)->first();

    if (!$comentario) {
        abort(404, 'Comentario no encontrada para este cliente.');
    }

    return view('admin.vercomentario', compact('cliente', 'comentario'));
}

// Mostrar el listado de clientes
public function index()
{
    $clientes = Empresas::all(); // Obtiene todos los registros de la tabla empresas
    return view('clientes.index', compact('clientes')); // Enviamos los datos a la vista
}

// Mostrar el formulario para crear un nuevo cliente
public function create()
{
    return view('clientes.create');
}

// Almacenar un nuevo cliente en la base de datos
public function store(Request $request)
{
    // Validamos los datos recibidos
    $request->validate([
        'Ruc' => 'required|max:11',
        'razon_social' => 'required|max:100',
        'nombre' => 'required|max:50',
        'telefono' => 'required|max:9',
        
    ]);

    // Creamos el nuevo cliente
    Empresas::create([
        'Ruc' => $request->Ruc,
        'razon_social' => $request->razon_social,
        'nombre' => $request->nombre,
        'telefono' => $request->telefono,
        
    ]);

    // Redirigimos a la vista de listado de clientes con un mensaje de éxito
    return redirect()->route('clientes.index')->with('success', 'Cliente registrado correctamente.');
}
    
    // Mostrar el formulario para editar un cliente
    public function edit($id)
    {
        $cliente = Empresas::findOrFail($id); // Obtener cliente por id
        return view('clientes.edit', compact('cliente'));
    }


    // Actualizar los datos de un cliente
    public function update(Request $request, $id)
    {
        $cliente = Empresas::findOrFail($id);

        // Validar los datos del cliente
        $request->validate([
            'Ruc' => 'required|max:11',
            'razon_social' => 'required|max:100',
            'nombre' => 'required|max:50',
            'telefono' => 'required|max:9',
            'estado' => 'required',
        ]);

        // Actualizamos los datos
        $cliente->update([
            'Ruc' => $request->Ruc,
            'razon_social' => $request->razon_social,
            'nombre' => $request->nombre,
            'telefono' => $request->telefono,
            'estado' => $request->estado,
        ]);

        return redirect()->route('clientes.index')->with('success', 'Cliente actualizado correctamente.');
    }
 
    // Eliminar un cliente
    public function destroy($id)
    {
        $cliente = Empresas::findOrFail($id);
        $cliente->delete(); // Eliminar cliente de la base de datos

        return redirect()->route('clientes.index')->with('success', 'Cliente eliminado correctamente.');
    }

    public function enviarMensajeWsp($id)
    {
        // Obtener el cliente (empresa) desde la base de datos usando el id
        $cliente = Empresas::findOrFail($id);
        
        // Verificar si el cliente tiene un número de teléfono registrado
        if ($cliente && $cliente->telefono) {
            // Preparar los datos que se enviarán a la API
            $data = [
                "messages" => [
                    [
                        "cellphone_number" => $cliente->telefono,
                        "customer" => $cliente->razon_social,
                        "service" => "Mr.Soft", // Reemplaza con el nombre de tu servicio
                        "username" => $cliente->Ruc,   // Reemplaza con el nombre de usuario de la API
                        "password" => $cliente->codigo_validacion  // Reemplaza con el password de la API
                    ]
                ]
            ];
    
            // Hacer la solicitud a la API de WhatsApp
            $response = Http::withHeaders([
                'Authorization' => '}*rA3>#pyM<dITk]]DFP2,/wc)1md_Y/' // Reemplaza con el token de autenticación
            ])->post('https://sistema.gesrest.net/api/send-feedback-invitations', $data);
            //dd($response->body());
            // Verificar si la solicitud fue exitosa
            if ($response->status() == 200) {
                return redirect()->route('admin.dashboard')->with('success', 'Mensaje de WhatsApp enviado correctamente.');
            } else {
                return redirect()->route('admin.dashboard')->with('error', 'Hubo un problema al enviar el mensaje.');
            }
        } else {
            return redirect()->route('admin.dashboard')->with('error', 'El cliente no tiene un número de teléfono registrado.');
        }
    }
   
}