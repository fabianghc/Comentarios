<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Empresas;
use App\Models\Comentarios;
#use Maatwebsite\Excel\Facades\Excel;
#use Maatwebsite\Excel\Excel;
use App\Exports\ComentariosExport;
#use App\Http\Controllers\ExportController;

class EmpresaController extends Controller
{
    //
    //
    public function index()
{
    return view('empresa.cargar');
}
public function import(Request $request)
{
    // Validar el archivo cargado
    $request->validate([
        'archivo' => 'required|mimes:xlsx,xls',
    ]);

    // Eliminar todos los registros actuales
    Empresas::truncate();

    // Leer el archivo Excel
    Excel::import(new \App\Imports\RestaurantesImport, $request->file('archivo'));

    return redirect()->back()->with('success', 'Los restaurantes fueron cargados exitosamente.');
}
public function showValidationForm()
    {
        return view('empresa.validacion');
    }

    public function validateCode(Request $request)
{
    $request->validate(['codigo' => 'required|string']);

    $restaurant = Empresas::where('codigo_validacion', $request->codigo)->first();

    if (!$restaurant) {
        return back()->withErrors(['codigo' => 'Código no válido']);
    }
    // Verificar si el restaurante ya ha respondido la encuesta
    $comentario_contestado = Comentarios::where('idEmpresa', $restaurant->idEmpresa)->exists();

    if ($comentario_contestado) {
        return view('empresa.comentario_contestado');
    }
    // Guarda el restaurante en la sesión
    session(['restaurant' => $restaurant]);

    // Redirige a la vista con el modal de bienvenida
    return view('empresa.confirmacion', ['restaurant' => $restaurant]);
}
public function showConfirmation(Request $request)
{
    $restaurant = session('restaurant'); // Obtener el restaurante de la sesión

    if (!$restaurant) {
        return redirect()->route('validacion.form'); // Si no hay restaurante en la sesión, redirige a la validación
    }

    return view('empresa.confirmacion', ['restaurant' => $restaurant]); // Mostrar la confirmación
}


public function showSurveyForm(Request $request)
{
    // Obtén el restaurante de la sesión
    $restaurant = session('restaurant');

    if (!$restaurant) {
        // Si no hay restaurante en la sesión, redirige al formulario de validación
        return redirect()->route('validacion.form');
    }

    // Muestra el formulario de encuesta
    return view('comentarios.index', ['restaurant' => $restaurant]);
}
public function submitSurvey(Request $request)
{
    $request->validate([
        'comentario' => 'required|string|max:255',
        'calificacion' => 'required|integer|between:1,5',
    ]);

    $restaurant = session('restaurant'); // Obtener el restaurante desde la sesión

    if (!$restaurant) {
        return redirect()->route('validacion.form'); // Si no hay restaurante, redirige a validación
    }

    // Guardar el comentario y la calificación en la base de datos
    Comentarios::create([
        'idEmpresa' => $request->idEmpresa,
        'comentario' => $request->comentario,
        'calificacion' => $request->calificacion,
    ]);
// Actualizar el estado del restaurante a 'S'
$restaurante = Empresas::find($request->input('idEmpresa'));
$restaurante->estado = 'S';
$restaurante->save();
// Limpia la sesión después de registrar la encuesta
session()->forget('restaurant');

    // Redireccionar con mensaje de éxito
    return redirect()->route('agradecimiento');
}


/*protected $excel;

    public function __construct(Excel $excel)
    {
        $this->excel = $excel;
    }

public function exportarComentarios()
{
    return $this->excel->download(new ComentariosExport(), 'Comentarios.xlsx');
}*/

}