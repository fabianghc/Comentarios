<?php
namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use App\Models\Administrador;
use App\Models\Restaurantes;
class LoginController extends Controller{
    public static $logueado = false; 
    public function showLoginForm()
    {
        return view('admin.login');
    }
    public function authenticate(Request $request)
{
    if (empty($guards)) {
        $guards = ['web']; // Fuerza el guard admin por defecto
    }

    foreach ($guards as $guard) {
        if (Auth::guard($guard)->check()) {
            return Auth::shouldUse($guard);
        }
    }
    #$this->unauthenticated($request, $guards);
    $credentials = $request->validate([
        'usuario' => 'required|string',
        'password' => 'required|string',
    ]);
// Autenticación con intento manual para evitar problemas con el nombre 'contraseña'
$admin = \App\Models\Administrador::where('usuario', $credentials['usuario'])->first();

if ($admin && Hash::check($credentials['password'], $admin->getAuthPassword())) {
    #Auth::guard('web')->login($admin);
    #dd(auth::guard('web')->check());
    #dd(Auth::check());
    #dd(Auth::guard('admin')->check(), Auth::guard('admin')->user());
    #session()->regenerate(); // Asegura que la sesión se mantenga activa
    
    #dd(Auth::guard('admin')->user()); // Verifica si Laravel realmente mantiene al usuario autenticado
    session()->put('logueado', true); 
    #dd($logueado);
    return redirect()->route('admin.dashboard');
    
}
return back()->withErrors(['error' => 'Usuario o contraseña incorrectos']);

// Devuelve error si las credenciales son incorrectas
//dd(Auth::guard('admin'));
}
}