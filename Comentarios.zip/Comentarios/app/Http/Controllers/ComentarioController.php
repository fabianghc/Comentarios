<?php
namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use App\Models\Administrador;
use App\Models\Empresas;
use App\Models\Comentarios;

class ComentarioController extends Controller  
{
    
    public function store(Request $request)
    {
        $validated = $request->validate([
            'comentario' => 'required|max:255',
            'calificacion' => 'required|integer|between:1,5',
        ]);
    
        Comentario::create([
            'comentario' => $request->comentario,
            'calificacion' => $request->calificacion,
            'idEmpresa' => $request->idEmpresa, // Si corresponde
        ]);
    
        return redirect()->route('comentarios.index')->with('success', 'Comentario registrado correctamente');
    }
   
    public function index()
    {
        // Lógica para mostrar los comentarios o el formulario de comentarios
        return view('comentarios.index');
    }
    


}