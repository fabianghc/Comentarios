<?php

namespace App\Http\Controllers;

use App\Models\Empresas; // Tu modelo de empresa
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Http;
use Illuminate\Routing\Controllers\HasMiddleware;
use Illuminate\Routing\Controllers\Middleware;
use PhpOffice\PhpSpreadsheet\IOFactory;

class ClienteController extends Controller
{ public static function middleware(): array
    {
        return [
            'web',
            new Middleware('log', only: ['index']),
            
        ];
    }
    // Mostrar el listado de clientes
    public function index()
    { 
        $this->middleware('web');
        if (!session('logueado', false)) { // ✅ Si no está logueado, lo mandamos al login
            #return redirect()->route('admin.login')->withErrors(['error' => 'Debes iniciar sesión']);
            return view('admin.login');
        }
        $clientes = Empresas::all(); // Obtiene todos los registros de la tabla empresas
        return view('empresa.index', compact('clientes')); // Enviamos los datos a la vista
    }

    // Mostrar el formulario para crear un nuevo cliente
    public function create()
    {
        return view('empresa.create');
    }

    // Almacenar un nuevo cliente en la base de datos
    public function store(Request $request)
    {
        // Validamos los datos recibidos
        $request->validate([
            'Ruc' => 'required|max:11',
            'razon_social' => 'required|max:100',
            'nombre' => 'required|max:50',
            'telefono' => 'required|max:9',
            'codigo_validacion' => 'required|size:4|digits:4', // Validación para 4 dígitos
        ]);

        // Creamos el nuevo cliente con estado 'N' por defecto
        Empresas::create([
            'Ruc' => $request->Ruc,
            'razon_social' => $request->razon_social,
            'nombre' => $request->nombre,
            'telefono' => $request->telefono,
            'codigo_validacion' => $request->codigo_validacion,
            'estado' => 'N', // Estado por defecto es 'N'
        ]);

        // Redirigimos a la vista de listado de clientes con un mensaje de éxito
        return redirect()->route('clientes.index')->with('success', 'Cliente registrado correctamente.');
    }

    // Mostrar el formulario para editar un cliente
    public function edit($id)
    {
        $cliente = Empresas::findOrFail($id); // Obtener cliente por id
        return view('empresa.edit', compact('cliente'));
    }

    // Actualizar los datos de un cliente
    public function update(Request $request, $id)
    {
        $cliente = Empresas::findOrFail($id);

        // Validar los datos del cliente
        $request->validate([
            'Ruc' => 'required|max:11',
            'razon_social' => 'required|max:100',
            'nombre' => 'required|max:50',
            'telefono' => 'required|max:9',
            'codigo_validacion' => 'required|size:4|digits:4', // Validación para 4 dígitos
        ]);

        // Actualizamos los datos
        $cliente->update([
            'Ruc' => $request->Ruc,
            'razon_social' => $request->razon_social,
            'nombre' => $request->nombre,
            'telefono' => $request->telefono,
            'codigo_validacion' => $request->codigo_validacion,
        ]);

        return redirect()->route('clientes.index')->with('success', 'Cliente actualizado correctamente.');
    }

    // Eliminar un cliente
    public function destroy($id)
    {
        $cliente = Empresas::findOrFail($id);
        $cliente->delete(); // Eliminar cliente de la base de datos

        return redirect()->route('clientes.index')->with('success', 'Cliente eliminado correctamente.');
    }

    public function enviarMensajeWsp($id)
{
    // Obtener el cliente (empresa) desde la base de datos usando el id
    $cliente = Empresas::findOrFail($id);
    
    // Verificar si el cliente tiene un número de teléfono registrado
    if ($cliente && $cliente->telefono) {
        // Preparar los datos que se enviarán a la API
        $data = [
            "messages" => [
                [
                    "cellphone_number" => $cliente->telefono,
                    "customer" => $cliente->razon_social,
                    "service" => "GESREST", // Reemplaza con el nombre de tu servicio
                    "username" => "test",   // Reemplaza con el nombre de usuario de la API
                    "password" => "123456"  // Reemplaza con el password de la API
                ]
            ]
        ];

        // Hacer la solicitud a la API de WhatsApp
        $response = Http::withHeaders([
            'Authorization' => 'Bearer tu_token_de_api' // Reemplaza con el token de autenticación
        ])->post('https://sistema.gesrest.net/api/send-feedback-invitations', $data);

        // Verificar si la solicitud fue exitosa
        if ($response->status() == 200) {
            return redirect()->route('dashboard')->with('success', 'Mensaje de WhatsApp enviado correctamente.');
        } else {
            return redirect()->route('dashboard')->with('error', 'Hubo un problema al enviar el mensaje.');
        }
    } else {
        return redirect()->route('dashboard')->with('error', 'El cliente no tiene un número de teléfono registrado.');
    }
    
}
public function showImportForm()
{
    return view('clientes.import'); // Vista donde el usuario selecciona el archivo Excel
}

public function import(Request $request)
{
    $request->validate([
        'excel_file' => 'required|mimes:xlsx,xls',
    ]);

    $file = $request->file('excel_file');
    $spreadsheet = IOFactory::load($file->getPathname());
    $sheet = $spreadsheet->getActiveSheet();
    $rows = $sheet->toArray();

    foreach ($rows as $index => $row) {
        if ($index == 0) continue; // Omitir encabezados

        // Ajusta estos índices según las columnas de tu archivo Excel
        $ruc = $row[0] ?? null;
        $razon_social = $row[1] ?? null;
        $nombre = $row[2] ?? null;
        $telefono = $row[3] ?? null; 
        $codigo_validacion = $row[4] ?? null;  // Agrega los campos que necesites

        // Validar si el cliente ya existe (puedes usar RUC o cualquier otro campo único)
        $exists = Empresas::where('Ruc', $ruc)->exists();
        
        if (!$exists) {
            Empresas::create([
                'Ruc' => $ruc,
                'razon_social' => $razon_social,
                'nombre' => $nombre,
                'telefono' => $telefono,
                'codigo_validacion' => $codigo_validacion,
                'estado' => 'N', // Estado por defecto, dependiendo de tu lógica
            ]);
        }
    }

    return redirect()->route('clientes.index')->with('success', 'Clientes importados correctamente.');
}



}

