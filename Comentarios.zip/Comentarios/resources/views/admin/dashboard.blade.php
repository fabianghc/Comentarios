<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
  <!-- Font Awesome (para íconos como el de WhatsApp) -->
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">

  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
  <title>Dashboard Administrador</title>
  <style>
    /* Estilos adicionales para un toque más colorido */
    .card-header {
      background: linear-gradient(90deg, #fe6055, #ff7b72);
      color: #fff;
    }
    .table thead {
      background-color: #343a40;
      color: #fff;
    }
    .btn-success {
      background-color: #28a745;
      border-color: #28a745;
    }
    /* Colores para las columnas de la tabla */
    .table-striped tbody tr td:nth-child(1) {
      background-color: #E3F2FD; /* Light Blue */
    }
    .table-striped tbody tr td:nth-child(2) {
      background-color: #FCE4EC; /* Light Pink */
    }
    .table-striped tbody tr td:nth-child(3) {
      background-color: #E8F5E9; /* Light Green */
    }
    .table-striped tbody tr td:nth-child(4) {
      background-color: #FFFDE7; /* Light Yellow */
    }
    .table-striped tbody tr td:nth-child(5) {
      background-color: #E1F5FE; /* Light Cyan */
    }
    
  </style>
</head>
<body>
   <!-- Navbar -->
   <nav class="navbar navbar-expand-lg navbar-dark" style="background: linear-gradient(90deg, #007bff, #00c6ff);">
    <div class="container-fluid">
      <a class="navbar-brand" href="#">Sistema de Comentarios </a>
      <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbarNav">
        <ul class="navbar-nav">
          <li class="nav-item">
            <a class="nav-link active" aria-current="page" href="{{ route('admin.dashboard') }}">Gestión de Comentarios</a>
          </li>
          <li class="nav-item">
            <a class="nav-link active" aria-current="page" href="{{ route('clientes.index') }}">Gestión de Clientes</a>
          </li>
        </ul>
      </div>
    </div>
  </nav>
  <div class="container mt-5">
    <div class="card shadow">
      <div class="card-header">
        <h1 class="mb-0">Listado de Respuestas de Clientes</h1>
      </div>
      <div class="card-body">
        @if($restaurantes->isEmpty())
          <div class="alert alert-info">No hay Clientes registrados aún.</div>
        @else
          <div class="table-responsive">
          @if(session('success'))
              <div class="alert alert-success">
                  {{ session('success') }}
              </div>
          @elseif(session('error'))
              <div class="alert alert-danger">
                  {{ session('error') }}
              </div>
          @endif
            <table class="table table-striped table-hover align-middle">
              <thead>
                <tr>
                  <th>#</th>
                  <th>RUC</th>
                  <th>Razón Social</th>
                  <th>Nombre</th>
                  <th>Telefono</th>
                  <th>Comentario Enviado</th>
                  <th>Acciones</th>
                </tr>
              </thead>
              <tbody>
                @foreach($restaurantes as $cliente)
                  <tr>
                    <td>{{ $loop->iteration }}</td>
                    <td>{{ $cliente->Ruc }}</td>
                    <td>{{ $cliente->razon_social }}</td>
                    <td>{{ $cliente->nombre }}</td>
                    <td>{{ $cliente->telefono }}</td>
                    <td>{{ $cliente->estado === 'S' ? 'Sí' : 'No' }}</td>
                    <td>
                      @if($cliente->estado === 'S')
                        <a href="{{ route('comentarios.ver', $cliente->idEmpresa) }}" class="btn btn-primary btn-sm" style="background: linear-gradient(90deg, #007bff, #00c6ff);">
                          Ver Comentario
                        </a>
                      @else
                        <!--<a href="#" class="btn btn-success btn-sm" style="background-color: #25D366;">
                          <i class="fab fa-whatsapp"></i> Enviar mensaje a WhatsApp
                        </a>-->
                        <form action="{{ route('enviar.wsp', $cliente->idEmpresa) }}" method="POST">
                            @csrf
                            
                          <!--<button type="submit" class="btn btn-success btn-sm" style="background-color: #25D366;" class="fab fa-whatsapp">Enviar mensaje a WhatsApp</button>
                          -->
                          <!--<a href="{{ route('enviar.wsp', $cliente->idEmpresa) }} " method="POST" class="btn btn-success btn-sm" style="background-color: #25D366;">
                          
                          <i class="fab fa-whatsapp"></i> Enviar mensaje a WhatsApp
                        </a>-->
                        <button type="submit" href="{{ route('enviar.wsp', $cliente->idEmpresa) }} " method="POST" class="btn btn-success btn-sm" style="background-color: #25D366;">
                        <i class="fab fa-whatsapp"></i> Enviar mensaje a WhatsApp
                        </button>
                        
                        </form>
                      @endif
                    </td>
                  </tr>
                @endforeach
              </tbody>
            </table>
          </div>
          <a href="{{ route('exportar.sql') }}" class="btn btn-success mb-3">
            Descargar Respuestas en Excel
          </a>
        @endif
      </div>
    </div>
  </div>
</body>
</html>

