<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Ver Comentario del Cliente</title>
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
  <style>
    body {
      background-color: #f4f6f9;
    }
    .card {
      border: none;
      border-radius: 10px;
      overflow: hidden;
      box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
    }
    .card-header {
      font-size: 1.25rem;
      font-weight: bold;
      color: #fff;
      padding: 1rem;
    }
    .card-header.restaurant {
      /*background: linear-gradient(90deg, #fe6055, #ff7b72);*/
      background: linear-gradient(90deg, #007bff, #00c6ff);
    }
    .card-header.encuesta {
      /*background: linear-gradient(90deg, #fe6055, #ff7b72);*/
      background: linear-gradient(90deg, #007bff, #00c6ff);
    }
    .card-body {
      background-color: #fff;
      padding: 1.5rem;
    }
    h1 {
      color: #333;
    }
    .stars {
      display: flex;
      justify-content: flex-start;
    }
    .stars label {
      font-size: 24px;
      color: #d3d3d3;
      cursor: pointer;
      transition: color 0.2s ease;
    }
    .stars label.checked {
      color: #ffcc00;
    }
  </style>
</head>
<body>
  <div class="container my-5">
    <h1 class="mb-4 text-center">📋 Ver Comentario del Cliente</h1>

    <div class="card mb-4">
      <div class="card-header restaurant">Datos del Cliente</div>
      <div class="card-body">
        <p><strong>Nombre:</strong> {{ $cliente->nombre }}</p>
        <p><strong>RUC:</strong> {{ $cliente->Ruc }}</p>
        <p><strong>Razón Social:</strong> {{ $cliente->razon_social }}</p>
      </div>
    </div>

    <div class="card">
      <div class="card-header encuesta">Comentario Enviado</div>
      <div class="card-body">
        <p><strong>Comentario:</strong> {{ $comentario->comentario }}</p>

        <p><strong>Calificación:</strong></p>
        <div class="stars" id="star-rating">
          <label>★</label>
          <label>★</label>
          <label>★</label>
          <label>★</label>
          <label>★</label>
        </div>
      </div>
    </div>
  </div>

  <script>
    // Obtener la calificación del backend
    var calificacion = {{ $comentario->calificacion }}; 

    // Obtener las etiquetas de las estrellas
    var stars = document.querySelectorAll('#star-rating label');

    // Iluminar las estrellas de acuerdo a la calificación
    for (var i = 0; i < calificacion; i++) {
      stars[i].classList.add('checked');
    }
  </script>
</body>
</html>




