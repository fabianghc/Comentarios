<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Actualizar Cliente - Sistema de Comentarios Mr. Soft</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" />
</head>
<body>
    <!-- Navbar style="background-color: #343a40;"-->
    <nav class="navbar navbar-expand-lg navbar-dark" style="background: linear-gradient(90deg, #007bff, #00c6ff);">
    <div class="container-fluid">
      <a class="navbar-brand" href="#">Sistema de Comentarios Mr. Soft</a>
      <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbarNav">
        <ul class="navbar-nav">
          <li class="nav-item">
            <a class="nav-link" href="/admin/dashboard">Gestión de Comentarios</a>
          </li>
          <li class="nav-item">
            <a class="nav-link active" href="/clientes">Gestión de Clientes</a>
          </li>
        </ul>
      </div>
    </div>
  </nav>

    <!-- Formulario de Actualización de Cliente -->
    <div class="container mt-5">
        <h1>Actualizar Cliente</h1>
        <form action="{{ route('clientes.update', $cliente->idEmpresa) }}" method="POST">
            @csrf
            @method('PUT')
            
            <div class="mb-3">
                <label for="Ruc" class="form-label">RUC</label>
                <input type="text" class="form-control" id="Ruc" name="Ruc" value="{{ old('Ruc', $cliente->Ruc) }}" required>
            </div>

            <div class="mb-3">
                <label for="razon_social" class="form-label">Razón Social</label>
                <input type="text" class="form-control" id="razon_social" name="razon_social" value="{{ old('razon_social', $cliente->razon_social) }}" required>
            </div>

            <div class="mb-3">
                <label for="nombre" class="form-label">Nombre</label>
                <input type="text" class="form-control" id="nombre" name="nombre" value="{{ old('nombre', $cliente->nombre) }}" required>
            </div>

            <div class="mb-3">
                <label for="telefono" class="form-label">Teléfono (todos los digitos juntos)</label>
                <input type="text" class="form-control" id="telefono" name="telefono" value="{{ old('telefono', $cliente->telefono) }}" required>
            </div>

            <div class="mb-3">
                <label for="codigo_validacion" class="form-label">Código de Validación (4 dígitos)</label>
                <input type="text" class="form-control" id="codigo_validacion" name="codigo_validacion" value="{{ old('codigo_validacion', $cliente->codigo_validacion) }}" required>
            </div>

            <button type="submit" class="btn btn-success">Actualizar Cliente</button>
        </form>
    </div>

    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
