<!DOCTYPE html> 
<html lang="es">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Encuesta ya respondida</title>
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
  <style>
    body {
      background: linear-gradient(90deg, #f8f9fa, #e9ecef);
      font-family: 'Helvetica Neue', Helvetica, Arial, sans-serif;
    }
    .message-container {
      display: flex;
      justify-content: center;
      align-items: center;
      height: 100vh;
    }
    .card {
      border: none;
      border-radius: 10px;
      overflow: hidden;
    }
    .card-header {
      /*background: linear-gradient(90deg, #fe6055, #ff7b72);*/
      background: linear-gradient(90deg, #007bff, #00c6ff);
      color: #fff;
      font-weight: bold;
      font-size: 1.25rem;
      border-bottom: none;
      padding: 1rem 1.5rem;
      font-weight: bold;
      text-decoration: underline;
      text-shadow: 2px 2px 4px rgba(0, 0, 0, 0.3);
    }
    .card-body {
      padding: 2rem;
    }
    .encuesta-respondida {
      /*color: #fe6055;*/
      color:rgb(0, 0, 0);
      text-decoration: underline;
      text-shadow: 2px 2px 4px rgba(0, 0, 0, 0.3);
    }
    .btn-primary {
      /*background: linear-gradient(90deg, #fe6055, #ff7b72);*/
      background: linear-gradient(90deg, #007bff, #00c6ff);
      border: none;
    }
  </style>
</head>
<body>
  <div class="container message-container mt-5">
    <div class="card shadow-lg text-center">
      <div class="card-header">
        Plataforma PULSO+
      </div>
      <div class="card-body">
        <h2 class="mb-4 encuesta-respondida">
          Ya registraste un comentario para esta plataforma
        </h2>
        <p class="lead">¡Gracias por compartir tu experiencia con nosotros!</p>
        <p>Seguimos trabajando para ofrecerte un mejor servicio.</p>
        <!-- <a href="{{ route('validacion.form') }}" class="btn btn-primary mt-3">Volver al inicio</a> -->
      </div>
    </div>
  </div>
</body>

</html>
