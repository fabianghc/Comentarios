<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
  <title>Gestión de Clientes</title>
  <style>
    .card-header {
      background: linear-gradient(90deg, #fe6055, #ff7b72);
      color: #fff;
    }
  </style>
</head>
<body>
  <!-- Navbar tyle="background-color: #343a40;" -->
  <nav class="navbar navbar-expand-lg navbar-dark" style="background: linear-gradient(90deg, #007bff, #00c6ff);">
    <div class="container-fluid">
      <a class="navbar-brand" href="#">Sistema de Comentarios</a>
      <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbarNav">
        <ul class="navbar-nav">
          <li class="nav-item">
            <a class="nav-link active" aria-current="page" href="{{ route('admin.dashboard') }}">Gestión de Comentarios</a>
          </li>
          <li class="nav-item">
            <a class="nav-link active" aria-current="page" href="{{ route('clientes.index') }}">Gestión de Clientes</a>
          </li>
        </ul>
      </div>
    </div>
  </nav>

  <!-- Contenido -->
  <div class="container mt-5">
    <h1>Listado de Clientes</h1>
    <a href="{{ route('clientes.create') }}" class="btn btn-success mb-3">Añadir Cliente</a>
    <a href="{{ route('clientes.import') }}" class="btn btn-primary mb-3">Importar Excel</a>

    <table class="table">
      <thead class="table-dark">
        <tr>
          <th scope="col">RUC</th>
          <th scope="col">Razón Social</th>
          <th scope="col">Nombre</th>
          <th scope="col">Teléfono</th>
          <th scope="col">codigo de validacion</th>
          <th scope="col">Acciones</th>
        </tr>
      </thead>
      <tbody>
        @foreach ($clientes as $cliente)
        <tr>
          <td>{{ $cliente->Ruc }}</td>
          <td>{{ $cliente->razon_social }}</td>
          <td>{{ $cliente->nombre }}</td>
          <td>{{ $cliente->telefono }}</td>
          <td>{{ $cliente->codigo_validacion }}</td>
          <td>
            <a href="{{ route('clientes.edit', $cliente->idEmpresa) }}" class="btn btn-primary">Actualizar</a>
            
            <form method="POST" action="{{ route('clientes.destroy', $cliente->idEmpresa) }}" style="display:inline;" onsubmit="return confirm('¿Estás seguro de que deseas eliminar este cliente?');">
              @csrf
              @method('DELETE')
              <button type="submit" class="btn btn-danger">Eliminar</button>
            </form>
          </td>
        </tr>
        @endforeach
      </tbody>
    </table>
    @if(session('success'))
    <div class="alert alert-success" role="alert">
      {{ session('success') }}
    </div>
    @endif
  </div>
</body>
</html>
