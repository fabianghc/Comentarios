<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
  <title>Agregar Cliente</title>
  <style>
    .card-header {
      background: linear-gradient(90deg, #fe6055, #ff7b72);
      color: #fff;
    }
  </style>
</head>
<body>
  <!-- Navbar style="background-color: #343a40;"-->
  <nav class="navbar navbar-expand-lg navbar-dark" style="background: linear-gradient(90deg, #007bff, #00c6ff);">
    <div class="container-fluid">
      <a class="navbar-brand" href="#">Sistema de Comentarios Mr. Soft</a>
      <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbarNav">
        <ul class="navbar-nav">
          <li class="nav-item">
            <a class="nav-link" href="/admin/dashboard">Gestión de Comentarios</a>
          </li>
          <li class="nav-item">
            <a class="nav-link active" href="/clientes">Gestión de Clientes</a>
          </li>
        </ul>
      </div>
    </div>
  </nav>

  <!-- Contenido -->
  <div class="container mt-5">
    <h1>Agregar Nuevo Cliente</h1>
    <form method="POST" action="{{ route('clientes.store') }}">
      @csrf
      <div class="mb-3">
        <label for="Ruc" class="form-label">RUC</label>
        <input type="text" class="form-control" id="Ruc" name="Ruc" required>
      </div>
      <div class="mb-3">
        <label for="razon_social" class="form-label">Razón Social</label>
        <input type="text" class="form-control" id="razon_social" name="razon_social" required>
      </div>
      <div class="mb-3">
        <label for="nombre" class="form-label">Nombre</label>
        <input type="text" class="form-control" id="nombre" name="nombre" required>
      </div>
      <div class="mb-3">
        <label for="telefono" class="form-label">Teléfono</label>
        <input type="text" class="form-control" id="telefono" name="telefono" required>
      </div>
      <div class="mb-3">
        <label for="codigo_validacion" class="form-label">Código de Validación (4 dígitos)</label>
        <input type="text" class="form-control" id="codigo_validacion" name="codigo_validacion" maxlength="4" minlength="4" required>
      </div>
      <button type="submit" class="btn btn-success">Registrar Cliente</button>
    </form>
  </div>
</body>
</html>
